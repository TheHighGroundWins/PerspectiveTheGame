welcome to make flatlands rippoff game.
controls for 3d are 
the WASD keys or the arrows keys both work

controls for 2d are AD for left and right or left and right for left and right
and WS for changing the depth or forward and backward for changing depth.

basically:
^
|
for getting small and the other arrow for getting big

for getting big and small in 2d make sure to press the back arrow or A first or else it doesn't seem to work due to annoying physics.

the numbers 2 is for 2d and 3 is for 3d.

hope you enjoy the game and I'm planning to improve the mode in the time until next week.

have a nice day,
Sincerely,
Juan
